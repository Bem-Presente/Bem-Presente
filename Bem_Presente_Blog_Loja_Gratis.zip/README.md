# Bem Presente — Blog + Loja grátis

Site estático pronto para publicação gratuita.

## Como usar
1. Abra `index.html` para testar.
2. Troque os produtos, preços e textos diretamente no `index.html`.
3. Troque o número do WhatsApp nos links `wa.me`.
4. Publique gratuitamente no GitHub Pages, Netlify ou Cloudflare Pages.

## Importante
O site usa WhatsApp como canal de compra. Para receber pagamentos online, você pode adicionar depois um link de pagamento (Mercado Pago, PagBank etc.).

## Estrutura
- index.html — página inicial, loja e blog
- style.css — visual
- script.js — menu mobile
- artigo-*.html — artigos do blog
